package entity;

public class QuestionRecord {
	@Override
	public String toString() {
		return "QuestionRecord [QNum=" + QNum + ", QType=" + QType + ", QSubject=" + QSubject + ", QText=" + QText
				+ ", QLevel=" + QLevel + ", QAnswer=" + QAnswer + ", A=" + A + ", B=" + B + ", C=" + C + ", D=" + D
				+ ", state=" + state + "]";
	}
	private int QNum; // 题号
	private String QType; // 题型
	private String QSubject; //科目名
	private String QText; //题目内容
	private float QLevel; //难度
	private String QAnswer; //答案
	private String A; //选项A
	private String B; //选项B
	private String C; //选项C
	private String D; //选项D
	private String state;
	
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public QuestionRecord() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getQNum() {
		return QNum;
	}
	public void setQNum(int qNum) {
		QNum = qNum;
	}
	public String getQType() {
		return QType;
	}
	public void setQType(String qType) {
		QType = qType;
	}
	public String getQSubject() {
		return QSubject;
	}
	public void setQSubject(String qSubject) {
		QSubject = qSubject;
	}

	public String getQText() {
		return QText;
	}
	public void setQText(String qText) {
		QText = qText;
	}
	public float getQLevel() {
		return QLevel;
	}
	public void setQLevel(float qLevel) {
		QLevel = qLevel;
	}
	public String getQAnswer() {
		return QAnswer;
	}
	public void setQAnswer(String qAnswer) {
		QAnswer = qAnswer;
	}
	public String getA() {
		return A;
	}
	public void setA(String a) {
		A = a;
	}
	public String getB() {
		return B;
	}
	public void setB(String b) {
		B = b;
	}
	public String getC() {
		return C;
	}
	public void setC(String c) {
		C = c;
	}
	public String getD() {
		return D;
	}
	public void setD(String d) {
		D = d;
	}
	
}
