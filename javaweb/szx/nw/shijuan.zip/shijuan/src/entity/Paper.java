package entity;

public class Paper {
	private int paperid;
	private String qNum;
	private String qGrade;
	private String phone;
	private String submittime;
	private String starttime;
	private String endtime;
	private String phones;

	public String getPhones() {
		return phones;
	}

	public void setPhones(String phones) {
		this.phones = phones;
	}

	public String getSubmittime() {
		return submittime;
	}

	public void setSubmittime(String submittime) {
		this.submittime = submittime;
	}

	public String getStarttime() {
		return starttime;
	}

	public void setStarttime(String starttime) {
		this.starttime = starttime;
	}

	public String getEndtime() {
		return endtime;
	}

	public void setEndtime(String endtime) {
		this.endtime = endtime;
	}

	public Paper() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getPaperid() {
		return paperid;
	}

	public void setPaperid(int paperid) {
		this.paperid = paperid;
	}

	public String getqNum() {
		return qNum;
	}

	public void setqNum(String qNum) {
		this.qNum = qNum;
	}

	public String getqGrade() {
		return qGrade;
	}

	public void setqGrade(String qGrade) {
		this.qGrade = qGrade;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	@Override
	public String toString() {
		return "Paper [paperid=" + paperid + ", qNum=" + qNum + ", qGrade=" + qGrade + ", phone=" + phone
				+ ", submittime=" + submittime + ", starttime=" + starttime + ", endtime=" + endtime + ", phones="
				+ phones + "]";
	}

}
