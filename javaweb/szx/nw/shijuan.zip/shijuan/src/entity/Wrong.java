package entity;

public class Wrong {
	private int wrongid;
	private int qnum;
	private String phone;

	public Wrong() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getWrongid() {
		return wrongid;
	}

	public void setWrongid(int wrongid) {
		this.wrongid = wrongid;
	}

	public int getQnum() {
		return qnum;
	}

	public void setQnum(int qnum) {
		this.qnum = qnum;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	@Override
	public String toString() {
		return "wrong [wrongid=" + wrongid + ", qnum=" + qnum + ", phone=" + phone + "]";
	}

}
