package entity;

public class Monitor {
	private String phone;
	private int paperid;
	private String processlist;
	private String submittime;
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public int getPaperid() {
		return paperid;
	}
	public void setPaperid(int paperid) {
		this.paperid = paperid;
	}
	public String getProcesslist() {
		return processlist;
	}
	public void setProcesslist(String processlist) {
		this.processlist = processlist;
	}
	public String getSubmittime() {
		return submittime;
	}
	public void setSubmittime(String submittime) {
		this.submittime = submittime;
	}
	@Override
	public String toString() {
		return "Monitor [phone=" + phone + ", paperid=" + paperid + ", processlist=" + processlist + ", submittime="
				+ submittime + "]";
	}
	
	
	
}
