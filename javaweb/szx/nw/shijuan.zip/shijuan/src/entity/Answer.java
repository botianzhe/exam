package entity;

public class Answer {
	private int answerid;
	private int paperid;
	private String aNum;
	private String grade;
	private String phone;
	private String submittime;

	public Answer() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getAnswerid() {
		return answerid;
	}

	public void setAnswerid(int answerid) {
		this.answerid = answerid;
	}

	public int getPaperid() {
		return paperid;
	}

	public void setPaperid(int paperid) {
		this.paperid = paperid;
	}

	public String getaNum() {
		return aNum;
	}

	public void setaNum(String aNum) {
		this.aNum = aNum;
	}

	public String getGrade() {
		return grade;
	}

	public void setGrade(String grade) {
		this.grade = grade;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getSubmittime() {
		return submittime;
	}

	public void setSubmittime(String submittime) {
		this.submittime = submittime;
	}
	
	@Override
	public String toString() {
		return "Answer [answerid=" + answerid + ", paperid=" + paperid + ", aNum=" + aNum + ", grade=" + grade
				+ ", phone=" + phone + ", submittime=" + submittime + "]";
	}

}
