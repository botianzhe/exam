package entity;

public class Users {
	private int id;
	private String phone;
	private String identity;
	private String name;
	private int age;
	private String gender;
	private String state;
	private float money;
	private float vip;

	public Users() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getIdentity() {
		return identity;
	}

	public void setIdentity(String identity) {
		this.identity = identity;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	

	@Override
	public String toString() {
		return "Users [id=" + id + ", phone=" + phone + ", identity=" + identity + ", name=" + name + ", age=" + age
				+ ", gender=" + gender + ", state=" + state + ", money=" + money + ", vip=" + vip + "]";
	}

	public String getState() {
		return state;
	}

	public void setState(String string) {
		this.state = string;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Users other = (Users) obj;
		if (other.getPhone() == null) {
			return false;
		}
		if (phone == null) {
			if (other.getPhone() != null)
				return false;
		} else if (!phone.equals(other.getPhone()))
			return false;
		return true;

	}

	public float getMoney() {
		return money;
	}

	public void setMoney(float money) {
		this.money = money;
	}

	public float getVip() {
		return vip;
	}

	public void setVip(float vip) {
		this.vip = vip;
	}

}