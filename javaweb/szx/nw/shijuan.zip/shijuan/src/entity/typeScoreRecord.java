package entity;

public class typeScoreRecord {
	public String type;
	public int score;

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public int getScore() {
		return score;
	}

	public void setScore(int score) {
		this.score = score;
	}

	public typeScoreRecord(String type, int score) {
		super();
		this.type = type;
		this.score = score;
	}

	public typeScoreRecord() {
		super();
	}

}
