package tools;
import java.io.File;
import java.io.IOException;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
public class ReadingPdf {

   public static String getText(String path){
	   
      //Loading an existing document
      File file = new File(path);
      PDFTextStripper pdfStripper = null;
		String text = null;
      PDDocument document = null;
	try {
		document = PDDocument.load(file);
		pdfStripper = new PDFTextStripper();
		text = pdfStripper.getText(document);
		document.close();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
      //Closing the document
      
	return text;

   }
}