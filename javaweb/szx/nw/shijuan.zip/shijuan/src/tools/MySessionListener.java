package tools;

import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

import dao.QuestionDAO;
import dao.UsersDAO;
import entity.Users;
 
public class MySessionListener implements HttpSessionListener {
 
       public void sessionCreated(HttpSessionEvent event) {
              System.out.println("start");
       }
 
       public void sessionDestroyed(HttpSessionEvent event) {
              HttpSession session = event.getSession();
              QuestionDAO qdao=new QuestionDAO();
//              qdao
              System.out.println(session.getId()+"finish");
       }
}