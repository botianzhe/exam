package tools;

import java.io.ByteArrayInputStream;

import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.poifs.filesystem.DirectoryEntry;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;

public class ExportDoc {

//	public static void main(String[] args) {
//		String destFile = "E:\\11.doc";
////#####################�����Զ������ݵ���Word�ĵ�#################################################
//		StringBuffer fileCon = new StringBuffer();
//		fileCon.append(" �Ŵ��� �� 317258963215223\n" + "2011 09 2013 07 3\n" + " �����о� ����\n" + "2013000001 2013 07 08");
//		fileCon.append("\n\r\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
//
//		new ExportDocTest().exportDoc(destFile, fileCon.toString());
//
//	}

	/**
	 * 
	 * @param destFile
	 * @param fileCon
	 */
	public static void exportDoc(String destFile, String fileCon) {
		try {
//doc content
			ByteArrayInputStream bais = new ByteArrayInputStream(fileCon.getBytes());
			POIFSFileSystem fs = new POIFSFileSystem();
			DirectoryEntry directory = fs.getRoot();
			directory.createDocument("WordDocument", bais);
			FileOutputStream ostream = new FileOutputStream(destFile);
			fs.writeFilesystem(ostream);
			bais.close();
			ostream.close();

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}