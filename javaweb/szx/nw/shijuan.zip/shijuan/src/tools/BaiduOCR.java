package tools;

import java.util.HashMap;
import org.json.JSONArray;
import org.json.JSONObject;
import com.baidu.aip.ocr.AipOcr;

public class BaiduOCR{
    //设置APPID/AK/SK
    public static final String APP_ID = "16257843";
    public static final String API_KEY = "sVClkNqrwwtqp2nVTXiGqjBu";
    public static final String SECRET_KEY = "sGIxmD5ZcymY8A2asHnmSS9PnNBsTyx2";
    
    public static String getword(AipOcr client,String imagepath) {
        // 传入可选参数调用接口
    	HashMap<String, String> options = new HashMap<String, String>();
        options.put("detect_direction", "true");
        options.put("probability", "true");

        // 参数为本地图片路径
        String image = imagepath;
        JSONObject res = client.basicAccurateGeneral(image, options);
//        System.out.println(res.toString(2));
        JSONArray words=res.getJSONArray("words_result");
        String result="";
        for(int i=0;i<words.length();i++) {
        	JSONObject w=(JSONObject) words.get(i);
        	result+=w.getString("words");
        	if(i!=words.length()-1) {
        		result+="\n";
        	}
        }
        System.out.println(result);
        return result;
    }
    public static  String extract(String imgpath) {
        // 初始化一个AipOcr
        AipOcr client = new AipOcr(APP_ID, API_KEY, SECRET_KEY);

        // 可选：设置网络连接参数
        client.setConnectionTimeoutInMillis(2000);
        client.setSocketTimeoutInMillis(60000);
        String res=getword(client,imgpath);
        // 可选：设置代理服务器地址, http和socket二选一，或者均不设置
//        client.setHttpProxy("proxy_host", proxy_port);  // 设置http代理
//        client.setSocketProxy("proxy_host", proxy_port);  // 设置socket代理
//
//        // 可选：设置log4j日志输出格式，若不设置，则使用默认配置
//        // 也可以直接通过jvm启动参数设置此环境变量
//        System.setProperty("aip.log4j.conf", "log4j.properties");
        System.out.println(res);
		return res;

    }
    
    
}