package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import entity.Monitor;
import util.DBUtils;

public class MonitorDAO {
	public void addAnswer(Monitor m) {
		Connection conn = null;
		PreparedStatement prep = null;
		try {
			conn = DBUtils.getConnection();
			String sql = "insert into monitor(phone,paperid,processlist,submittime)values(?,?,?,?)";
			prep = conn.prepareStatement(sql);
			prep.setString(1, m.getPhone());
			prep.setInt(2, m.getPaperid());
			prep.setString(3, m.getProcesslist());
			SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			String submittime=sdf.format(new Date());
			prep.setString(4, submittime);
			prep.executeUpdate();
			conn.close();
			prep.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public List<Monitor> getPaperlistById(int paperid){
		List<Monitor> list=new ArrayList<Monitor>();
		Connection conn=null;
		PreparedStatement prep=null;
		ResultSet rs=null;
		try {
			conn=DBUtils.getConnection();
			String sql="select * from monitor where paperid=?";
			prep=conn.prepareStatement(sql);
			prep.setInt(1,paperid);
			rs=prep.executeQuery();
			while(rs.next()){
				Monitor m=new Monitor();
				m.setPaperid(paperid);
				m.setPhone(rs.getString("phone"));
				m.setProcesslist(rs.getString("processlist"));
				m.setSubmittime(rs.getString("submittime"));
				list.add(m);
			}
		}catch (SQLException e) {
			e.printStackTrace();
		}finally {
			DBUtils.closeAll(rs, prep, conn);
		}
		return list;
	}
	
}
