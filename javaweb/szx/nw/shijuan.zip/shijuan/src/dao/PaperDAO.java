package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import entity.Paper;
import util.DBUtils;

public class PaperDAO {
	public void addPaper(String qNum,String qGrade,String phone) throws SQLException{
		Connection conn=null;
		PreparedStatement prep=null;
		try {
			conn=DBUtils.getConnection();
			String sql="insert into paper(qnum,qgrade,phone,submittime,starttime,endtime,phones)values(?,?,?,?,?,?,?)";
			prep=conn.prepareStatement(sql);
			prep.setString(1, qNum);
			prep.setString(2, qGrade);
			prep.setString(3, phone);

			SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			String submittime=sdf.format(new Date());
			prep.setString(4,submittime);
			prep.setString(5,"未设置");
			prep.setString(6,"未设置");
			prep.setString(7,"未设置");
			prep.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			conn.close();
			prep.close();
		}
	}
	
	public void updatePaperSet(String startdate,String starttime,String enddate,String endtime,String phones,int paperid)throws SQLException{
		Connection conn=null;
		PreparedStatement prep=null;
		try {
			conn=DBUtils.getConnection();
			String sql="update paper set starttime=?,endtime=?,phones=? where paperid=?";
			prep=conn.prepareStatement(sql);
			prep.setString(1, startdate+" "+starttime);
			prep.setString(2, enddate+" "+endtime);
			prep.setString(3,phones);
			prep.setInt(4, paperid);
			
			prep.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		}finally {
			conn.close();
			prep.close();
		}
	}
	
	public List<Paper> showPaperList()throws SQLException{
		List<Paper> papers=new ArrayList<Paper>();
		
		Connection conn=null;
		PreparedStatement prep=null;
		ResultSet rs=null;
		try {
			conn=DBUtils.getConnection();
			String sql="select * from paper where phones='未设置'";
			prep=conn.prepareStatement(sql);
			rs=prep.executeQuery();
			
			while(rs.next()){
				Paper paper=new Paper();
				paper.setPaperid(rs.getInt("paperid"));
				paper.setqNum(rs.getString("qnum"));
				paper.setqGrade(rs.getString("qgrade"));
				paper.setSubmittime(rs.getString("submittime"));
				paper.setPhone(rs.getString("phone"));
				papers.add(paper);
			}
		}catch (SQLException e) {
			e.printStackTrace();
			throw e;
		}finally {
			DBUtils.closeAll(rs, prep, conn);
		}
		
		return papers;
	}
	
	public Paper showPaperByPaperid(int paperid)throws SQLException{
		Paper paper=null;
		Connection conn=null;
		PreparedStatement prep=null;
		ResultSet rs=null;
		try {
			conn=DBUtils.getConnection();
			String sql="select * from paper where paperid=?";
			prep=conn.prepareStatement(sql);
			prep.setInt(1, paperid);
			rs=prep.executeQuery();
			
			while(rs.next()){
				paper=new Paper();
				paper.setPaperid(rs.getInt("paperid"));
				paper.setqNum(rs.getString("qnum"));
				paper.setqGrade(rs.getString("qgrade"));
				paper.setPhone(rs.getString("phone"));
			}
		}catch (SQLException e) {
			e.printStackTrace();
			throw e;
		}finally {
			DBUtils.closeAll(rs, prep, conn);
		}
		
		return paper;
	}
	public List<Paper> showPaperListByPhone(String phone)throws SQLException{
		List<Paper> papers=new ArrayList<Paper>();
		
		Connection conn=null;
		PreparedStatement prep=null;
		ResultSet rs=null;
		try {
			conn=DBUtils.getConnection();
			String sql="select * from paper where phone=? order by paperid desc";
			prep=conn.prepareStatement(sql);
			prep.setString(1, phone);
			rs=prep.executeQuery();
			while(rs.next()){
				Paper paper=new Paper();
				paper.setPaperid(rs.getInt("paperid"));
				paper.setqNum(rs.getString("qnum"));
				paper.setqGrade(rs.getString("qgrade"));
				paper.setPhone(rs.getString("phone"));
				paper.setSubmittime(rs.getString("submittime"));
				paper.setStarttime(rs.getString("starttime"));
				paper.setEndtime(rs.getString("endtime"));
				paper.setPhones(rs.getString("phones"));
				papers.add(paper);
			}
		}catch (SQLException e) {
			e.printStackTrace();
			throw e;
		}finally {
			DBUtils.closeAll(rs, prep, conn);
		}
		return papers;
	}
	
	public String getPaperlistString(String phone){
		String res="";
		
		Connection conn=null;
		PreparedStatement prep=null;
		ResultSet rs=null;
		try {
			conn=DBUtils.getConnection();
			String sql="select distinct paperid from paper where phone=?";
			prep=conn.prepareStatement(sql);
			prep.setString(1, phone);
			rs=prep.executeQuery();
			while(rs.next()){
				res+=rs.getInt("paperid")+",";
			}
		}catch (SQLException e) {
			e.printStackTrace();
		}finally {
			DBUtils.closeAll(rs, prep, conn);
		}
		return res;
	}
	
	public List<Paper> showPaperListByOnephone(String onephone)throws SQLException, ParseException{
		List<Paper> papers=new ArrayList<Paper>();
		
		Connection conn=null;
		PreparedStatement prep=null;
		ResultSet rs=null;
		try {
			conn=DBUtils.getConnection();
			String sql="select * from paper";
			prep=conn.prepareStatement(sql);
			rs=prep.executeQuery();
			
			while(rs.next()){
				String phones=rs.getString("phones");
				String starttime=rs.getString("starttime");
				String endtime=rs.getString("endtime");
				if(phones!=null){
					String allphone[]=phones.split(";");
					for(int i=0;i<allphone.length;i++){
						if(onephone.equals(allphone[i])&&!starttime.equals("未设置")&&!endtime.equals("未设置")){
							SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
							Date start=sdf.parse(starttime);
							Date end=sdf.parse(endtime);
							Date now=new Date();
							if(now.getTime()>=start.getTime()&&now.getTime()<=end.getTime()){
								Paper paper=new Paper();
								paper.setPaperid(rs.getInt("paperid"));
								paper.setqNum(rs.getString("qnum"));
								paper.setqGrade(rs.getString("qgrade"));
								paper.setPhone(rs.getString("phone"));
								paper.setSubmittime(rs.getString("submittime"));
								paper.setStarttime(rs.getString("starttime"));
								paper.setEndtime(rs.getString("endtime"));
								paper.setPhones(rs.getString("phones"));
								papers.add(paper);
							}
						}
					}
				}
			}
		}catch (SQLException e) {
			e.printStackTrace();
			throw e;
		}finally {
			DBUtils.closeAll(rs, prep, conn);
		}
		return papers;
	}
	
}
