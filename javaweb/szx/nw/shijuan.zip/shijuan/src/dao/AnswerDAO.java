package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import entity.Answer;
import util.DBUtils;

public class AnswerDAO {
	public void addAnswer(int paperid,String aNum,String phone) throws SQLException{
		Connection conn=null;
		PreparedStatement prep=null;
		try {
			conn=DBUtils.getConnection();
			String sql="insert into answer(paperid,aNum,phone,submittime)values(?,?,?,?)";
			prep=conn.prepareStatement(sql);
			prep.setInt(1, paperid);
			prep.setString(2, aNum);
			prep.setString(3, phone);
			
			SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			String submittime=sdf.format(new Date());
			prep.setString(4, submittime);
			prep.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally {
			conn.close();
			prep.close();
		}
	}
	
	public void addGrade(String grade,int answerid) throws SQLException{
		Connection conn=null;
		PreparedStatement prep=null;
		try {
			conn=DBUtils.getConnection();
			String sql="update answer set grade=? where answerid=?";
			prep=conn.prepareStatement(sql);
			prep.setString(1, grade);
			prep.setInt(2, answerid);
			prep.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			conn.close();
			prep.close();
		}
	}
	
	public List<Answer> showGraderListByPhone(String phone)throws SQLException{
		List<Answer> answers=new ArrayList<Answer>();
		
		Connection conn=null;
		PreparedStatement prep=null;
		ResultSet rs=null;
		try {
			conn=DBUtils.getConnection();
			String sql="select * from answer where phone=? order by answerid desc ";
			prep=conn.prepareStatement(sql);
			prep.setString(1, phone);
			rs=prep.executeQuery();
			while(rs.next()){
				Answer answer=new Answer();
				answer.setAnswerid(rs.getInt("answerid"));
				answer.setPaperid(rs.getInt("paperid"));
				answer.setaNum(rs.getString("anum"));
				answer.setGrade(rs.getString("grade"));
				answer.setPhone(rs.getString("phone"));
				answer.setSubmittime(rs.getString("submittime"));
				answers.add(answer);
			}
		}catch (SQLException e) {
			e.printStackTrace();
			throw e;
		}finally {
			DBUtils.closeAll(rs, prep, conn);
		}
		
		return answers;
	}
	
	public List<Answer> showGradesListByPaperid(String paperid)throws SQLException{
		List<Answer> answers=new ArrayList<Answer>();
		
		Connection conn=null;
		PreparedStatement prep=null;
		ResultSet rs=null;
		try {
			conn=DBUtils.getConnection();
			String sql="select * from answer where paperid=? order by grade desc ";
			prep=conn.prepareStatement(sql);
			prep.setString(1, paperid);
			rs=prep.executeQuery();
			while(rs.next()){
				Answer answer=new Answer();
				answer.setAnswerid(rs.getInt("answerid"));
				answer.setPaperid(rs.getInt("paperid"));
				answer.setaNum(rs.getString("anum"));
				answer.setGrade(rs.getString("grade"));
				answer.setPhone(rs.getString("phone"));
				answer.setSubmittime(rs.getString("submittime"));
				answers.add(answer);
			}
		}catch (SQLException e) {
			e.printStackTrace();
			throw e;
		}finally {
			DBUtils.closeAll(rs, prep, conn);
		}
		
		return answers;
	}
}
