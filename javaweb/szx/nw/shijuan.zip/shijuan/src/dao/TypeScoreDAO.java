package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import entity.typeScoreRecord;
import util.DBUtils;

public class TypeScoreDAO {
	public boolean updateScore(String type,int score) {
		Connection conn = null;
		PreparedStatement ps = null;
		try {
			conn = DBUtils.getConnection();
			String sql = "update subject set SScore=? where SName=?";
			ps = conn.prepareStatement(sql);
			ps.setInt(1, score);
			ps.setString(2, type);
			if(ps.executeUpdate()==1) return true;
			ps.close();
			conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false; 
	}
	public List<typeScoreRecord> getTypeScores() {
		List<typeScoreRecord> list = new ArrayList<typeScoreRecord>();
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			conn = DBUtils.getConnection();
			String sql = "select * from subject";
			ps = conn.prepareStatement(sql);
			System.out.println(ps.toString());
			rs = ps.executeQuery();
			System.out.println(rs.toString());
			while (rs.next()) {
				typeScoreRecord t=new typeScoreRecord();
				t.setType(rs.getString(1));
				t.setScore(rs.getInt(2));
				list.add(t);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			DBUtils.closeAll(rs, ps, conn);
		}
		return list;

	}

}
