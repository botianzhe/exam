package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import entity.Paper;
import entity.Wrong;
import util.DBUtils;

public class WrongDAO {
	public void addWrongQnum(int qnum,String phone) throws SQLException{
		Connection conn=null;
		PreparedStatement prep=null;
		try {
			conn=DBUtils.getConnection();
			String sql="insert into wrong(qnum,phone)values(?,?)";
			prep=conn.prepareStatement(sql);
			prep.setInt(1, qnum);
			prep.setString(2, phone);
			prep.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			conn.close();
			prep.close();
		}
	}
	
	public List<Wrong> showWrongListByPhone(String phone)throws SQLException{
		List<Wrong> wrongs=new ArrayList<Wrong>();
		
		Connection conn=null;
		PreparedStatement prep=null;
		ResultSet rs=null;
		try {
			conn=DBUtils.getConnection();
			String sql="select * from wrong where phone=? order by wrongid desc";
			prep=conn.prepareStatement(sql);
			prep.setString(1, phone);
			rs=prep.executeQuery();
			while(rs.next()){
				Wrong wrong=new Wrong();
				wrong.setWrongid(rs.getInt("wrongid"));
				wrong.setQnum(rs.getInt("qnum"));
				wrong.setPhone(rs.getString("phone"));
				wrongs.add(wrong);
			}
		}catch (SQLException e) {
			e.printStackTrace();
			throw e;
		}finally {
			DBUtils.closeAll(rs, prep, conn);
		}
		
		return wrongs;
	}
}
