package dao;

import java.io.FileInputStream;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import entity.QuestionRecord;
import util.DBUtils;

public class QuestionDAO {

	public boolean AddQuestion(QuestionRecord q) {
		boolean flag = false;
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		String sql = null;
		if (q.getQType().equals("选择题"))
			sql = "insert into question (QType,QSubject,QText,QLevel,QAnswer,A,B,C,D) values(?,?,?,?,?,?,?,?,?)";
		else
			sql = "insert into question (QType,QSubject,QText,QLevel,QAnswer) values(?,?,?,?,?)";
		// 获取数据库连接对象

		// 通过连接对象获取预编译声明对象PreparedStatement
		try {
			conn = DBUtils.getConnection();
			ps = conn.prepareStatement(sql);
			ps.setString(1, q.getQType());
			ps.setString(2, q.getQSubject());
			ps.setString(3, q.getQText());
			ps.setFloat(4, q.getQLevel());
			ps.setString(5, q.getQAnswer());
			if (q.getQType().equals("选择题")) {
				ps.setString(6, q.getA());
				ps.setString(7, q.getB());
				ps.setString(8, q.getC());
				ps.setString(9, q.getD());
			}
			System.out.println(ps);
			flag = ps.executeUpdate() > 0 ? true : false;
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}finally {
			DBUtils.closeAll(rs, ps, conn);
		}
		return flag;
	}
	public boolean AddQuestionWithPic(QuestionRecord q,FileInputStream in) {
		boolean flag = false;
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		String sql = null;
		if (q.getQType().equals("选择题"))
			sql = "insert into question (QType,QSubject,QText,QLevel,QAnswer,A,B,C,D,photo) values(?,?,?,?,?,?,?,?,?,?)";
		else
			sql = "insert into question (QType,QSubject,QText,QLevel,QAnswer) values(?,?,?,?,?)";
		// 获取数据库连接对象

		// 通过连接对象获取预编译声明对象PreparedStatement
		try {
			conn = DBUtils.getConnection();
			ps = conn.prepareStatement(sql);
			ps.setString(1, q.getQType());
			ps.setString(2, q.getQSubject());
			ps.setString(3, q.getQText());
			ps.setFloat(4, q.getQLevel());
			ps.setString(5, q.getQAnswer());
			if (q.getQType().equals("选择题")) {
				ps.setString(6, q.getA());
				ps.setString(7, q.getB());
				ps.setString(8, q.getC());
				ps.setString(9, q.getD());
				ps.setBinaryStream(10, in,in.available());
			}
			System.out.println(ps);
			flag = ps.executeUpdate() > 0 ? true : false;
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			DBUtils.closeAll(rs, ps, conn);
		}
		return flag;
	}
	public List<QuestionRecord> getquestions(String type, String subject, float small,float large, String qnum) {
		List<QuestionRecord> list = new ArrayList<QuestionRecord>();
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			conn = DBUtils.getConnection();
			String nums="''";
			if(!"".equals(qnum)) {
				nums = qnum.substring(0,qnum.length()-1);
			}
			String sql = "select * from question where QType='"+type+"' and QSubject='"+subject+"' and QNum not in ("+nums+") and QLevel between "+small+" and "+large;
			ps = conn.prepareStatement(sql);
			System.out.println(ps.toString());
			rs = ps.executeQuery();
			System.out.println(rs.toString());
			while (rs.next()) {

				QuestionRecord q = new QuestionRecord();
				q.setQNum(rs.getInt(1));
				q.setQType(rs.getString(2));
				q.setQSubject(rs.getString(3));
				q.setQText(rs.getString(4));
				q.setQLevel(rs.getFloat(5));
				q.setQAnswer(rs.getString(6));
				q.setA(rs.getString(7));
				q.setB(rs.getString(8));
				q.setC(rs.getString(9));
				q.setD(rs.getString(10));
				list.add(q);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			DBUtils.closeAll(rs, ps, conn);
		}
		return list;

	}


	public List<QuestionRecord> findQuestion(String num) {
		List<QuestionRecord> list = new ArrayList<QuestionRecord>();
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		// 编写SQL语句
		String sql = "select * from question where QNum in (" + num + ")";
		
		// 通过连接对象获取预编译声明对象PreparedStatement
		try {
			conn = DBUtils.getConnection();
			ps = conn.prepareStatement(sql);
			System.out.println(ps);
			rs = ps.executeQuery();
			// 循环遍历结果集对象
			while (rs.next()) {
				QuestionRecord q = new QuestionRecord();
				q.setQNum(rs.getInt(1));
				q.setQType(rs.getString(2));
				q.setQSubject(rs.getString(3));
				q.setQText(rs.getString(4));
				q.setQLevel(rs.getFloat(5));
				q.setQAnswer(rs.getString(6));
				q.setA(rs.getString(7));
				q.setB(rs.getString(8));
				q.setC(rs.getString(9));
				q.setD(rs.getString(10));
				list.add(q);
			}
			return list;
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}finally {
			DBUtils.closeAll(rs, ps, conn);
		}
	}
	
	public List<String> findQuestionSubjects() {
		List<String> list = new ArrayList<String>();
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		// 编写SQL语句
		String sql = "select distinct QSubject from question";
		
		// 通过连接对象获取预编译声明对象PreparedStatement
		try {
			conn = DBUtils.getConnection();
			ps = conn.prepareStatement(sql);
			System.out.println(ps);
			rs = ps.executeQuery();
			// 循环遍历结果集对象
			while (rs.next()) {
				String a=rs.getString("QSubject");
				list.add(a);
			}
			return list;
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}finally {
			DBUtils.closeAll(rs, ps, conn);
		} 
	}
	public Blob findImageById(String questionid) {
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		// 编写SQL语句
		String sql = "select photo from question where QNum=?";
		Blob b=null;
		// 通过连接对象获取预编译声明对象PreparedStatement
		try {
			conn = DBUtils.getConnection();
			ps = conn.prepareStatement(sql);
			ps.setString(1, questionid);
			System.out.println(ps);
			rs = ps.executeQuery();
			// 循环遍历结果集对象
			while (rs.next()) {
				b=rs.getBlob("photo");
			}
			return b;
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}finally {
			DBUtils.closeAll(rs, ps, conn);
		} 
	}
	public boolean DelQuestion(int num)throws SQLException{
		boolean flag=false;
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		String sql = "delete from question where Qnum = "+num;
		System.out.println(sql);
	//获取数据库连接对象	
		conn = DBUtils.getConnection();
		//通过连接对象获取预编译声明对象PreparedStatement 
		try {
			ps = conn.prepareStatement(sql);
			flag = ps.executeUpdate()>0 ? true:false;
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}finally {
			DBUtils.closeAll(rs, ps, conn);
		}
		return flag;
	}

	
	
	
	public List<String> getSubject(){
		List<String> list = new ArrayList<String>();
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		//编写SQL语句
		String sql = "select SName from subject";
	//获取数据库连接对象	
		
		//通过连接对象获取预编译声明对象PreparedStatement 
		try {
			conn = DBUtils.getConnection();
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
			//循环遍历结果集对象
			while (rs.next()) {
				list.add(rs.getString(1));
			}
			 return list;
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}finally {
			DBUtils.closeAll(rs, ps, conn);
		}
	}
	public List<QuestionRecord> getType() throws SQLException{
		List<QuestionRecord> list = new ArrayList<QuestionRecord>();
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		//编写SQL语句
		String sql = "select SType from type";
	//获取数据库连接对象	
		conn = DBUtils.getConnection();
		//通过连接对象获取预编译声明对象PreparedStatement 
		try {
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
			//循环遍历结果集对象
			while (rs.next()) {
				QuestionRecord q = new QuestionRecord();
				q.setQType(rs.getString(1));
				list.add(q);
			}
			 return list;
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}finally {
			DBUtils.closeAll(rs, ps, conn);
		}
	}
	public List<String> getAllSubjectDistinct(){
		List<String> list = new ArrayList<String>();
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		//编写SQL语句
		String sql = "select distinct QSubject from question";		
		//通过连接对象获取预编译声明对象PreparedStatement 
		try {
			conn = DBUtils.getConnection();
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
			//循环遍历结果集对象
			while (rs.next()) {
				list.add(rs.getString(1));
			}
			 return list;
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}finally {
			DBUtils.closeAll(rs, ps, conn);
		}
	}

	public int getTypeCount(String type,List<QuestionRecord> list){
		int i;
		for(i=0;i<list.size();i++){
			if(i<list.size()-1)
			if(list.get(i).getQType().equals(type)&&!list.get(i+1).getQType().equals(type)){
				break;
			}
		}
		return i;
	}
	
	
	
	public QuestionRecord showQuestionByQid(int qid)throws SQLException{
		QuestionRecord question=null;
		Connection conn=null;
		PreparedStatement prep=null;
		ResultSet rs=null;
		try {
			conn=DBUtils.getConnection();
			String sql="select * from question where QNum=?";
			prep=conn.prepareStatement(sql);
			prep.setInt(1, qid);
			rs=prep.executeQuery();

			while(rs.next()){
				question=new QuestionRecord();
				question.setQText(rs.getString("QText"));
				question.setQAnswer(rs.getString("qAnswer"));
				question.setA(rs.getString("A"));
				question.setB(rs.getString("B"));
				question.setC(rs.getString("C"));
				question.setD(rs.getString("D"));
			}
		}catch (SQLException e) {
			e.printStackTrace();
			throw e;
		}finally {
			DBUtils.closeAll(rs, prep, conn);
		}
		
		return question;
	}
	public void resetState() {
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		String sql = "update question set state=0";
		System.out.println(sql);
	//获取数据库连接对象	
		
		//通过连接对象获取预编译声明对象PreparedStatement 
		try {
			conn = DBUtils.getConnection();
			ps = conn.prepareStatement(sql);
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}finally {
			DBUtils.closeAll(rs, ps, conn);
		}
	}

}
