package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import entity.Users;
import util.DBUtils;

public class UsersDAO {
	public Users findByPhone(String phone) throws SQLException{
		Users user=null;
		Connection conn=null;
		PreparedStatement prep=null;
		ResultSet rs=null;
		try {
			conn=DBUtils.getConnection();
			String sql="select * from users where phone=?";
			prep=conn.prepareStatement(sql);
			prep.setString(1, phone);
			rs=prep.executeQuery();
			
			while(rs.next()){
				user=new Users();
				user.setId(rs.getInt("id"));
				user.setPhone(rs.getString("phone"));
				user.setIdentity(rs.getString("identity"));
				user.setName(rs.getString("name"));
				user.setAge(rs.getInt("age"));
				user.setGender(rs.getString("gender"));
				user.setMoney(rs.getFloat("money"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		}finally {
			DBUtils.closeAll(rs, prep, conn);
		}
		return user;
	}
	
	public void addByPhone(Users user) throws SQLException{
		Connection conn=null;
		PreparedStatement prep=null;
		try {
			conn=DBUtils.getConnection();
			String sql="insert into users(phone,identity)values(?,?)";
			prep=conn.prepareStatement(sql);
			prep.setString(1, user.getPhone());
			prep.setString(2, user.getIdentity());
			prep.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			conn.close();
			prep.close();
		}
	}
	
	public void modify(Users user,String phone) throws SQLException{
		Connection conn=null;
		PreparedStatement prep=null;
		try {
			conn=DBUtils.getConnection();
			String sql="update users set name=?,gender=?,age=?,phone=? where phone=?";
			prep=conn.prepareStatement(sql);
			prep.setString(1, user.getName());
			prep.setString(2, user.getGender());
			prep.setInt(3, user.getAge());
			prep.setString(4, user.getPhone());
			prep.setString(5,phone);
			prep.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		}finally {
			conn.close();
			prep.close();
		}
	}
	
	public boolean updateState(String state,String phone){
		Connection conn=null;
		PreparedStatement prep=null;
		try {
			conn=DBUtils.getConnection();
			String sql="update users set state=? where phone=?";
			prep=conn.prepareStatement(sql);
			prep.setString(1, state);
			prep.setString(2, phone);
			if(prep.executeUpdate()!=0) {
				return true;
			}
			conn.close();
			prep.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}

	public List<Users> findByState(String state){
		List<Users> userlist=new ArrayList<Users>();
		Connection conn=null;
		PreparedStatement prep=null;
		ResultSet rs=null;
		try {
			conn=DBUtils.getConnection();
			String sql="select * from users where state=?";
			prep=conn.prepareStatement(sql);
			prep.setString(1, state);
			rs=prep.executeQuery();
			
			while(rs.next()){
				Users user=new Users();
				user.setId(rs.getInt("id"));
				user.setPhone(rs.getString("phone"));
				user.setIdentity(rs.getString("identity"));
				user.setName(rs.getString("name"));
				user.setAge(rs.getInt("age"));
				user.setGender(rs.getString("gender"));
				user.setState(rs.getString("state"));
				userlist.add(user);
				
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			DBUtils.closeAll(rs, prep, conn);
		}
		return userlist;
	}
	public String  findState(String phone){
		String state = "";
		Connection conn=null;
		PreparedStatement prep=null;
		ResultSet rs=null;
		try {
			conn=DBUtils.getConnection();
			String sql="select state from users where phone=?";
			prep=conn.prepareStatement(sql);
			prep.setString(1, phone);
			rs=prep.executeQuery();
			
			while(rs.next()){
				state=rs.getString(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			DBUtils.closeAll(rs, prep, conn);
		}
		return state;
	}
	public boolean resetState(String phone){
		Connection conn=null;
		PreparedStatement prep=null;
		try {
			conn=DBUtils.getConnection();
			String sql="update users set state='0' where phone=?";
			prep=conn.prepareStatement(sql);
			prep.setString(1, phone);
			if(prep.executeUpdate()!=0) {
				return true;
			}
			conn.close();
			prep.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}
	public boolean updateMoney(String phone,float money){
		Connection conn=null;
		PreparedStatement prep=null;
		try {
			conn=DBUtils.getConnection();
			String sql="update users set money=money+? where phone=?";
			prep=conn.prepareStatement(sql);
			prep.setFloat(1, money);
			prep.setString(2, phone);
			if(prep.executeUpdate()!=0) {
				return true;
			}
			conn.close();
			prep.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}
	
}
