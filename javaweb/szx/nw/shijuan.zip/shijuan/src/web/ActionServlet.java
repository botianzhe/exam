package web;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Blob;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import dao.AnswerDAO;
import dao.MonitorDAO;
import dao.PaperDAO;
import dao.QuestionDAO;
import dao.TypeScoreDAO;
import dao.UsersDAO;
import dao.WrongDAO;
import entity.Answer;
import entity.Monitor;
import entity.Paper;
import entity.QuestionRecord;
import entity.Users;
import entity.typeScoreRecord;
import tools.BaiduOCR;
import tools.CommonRpc;
import tools.DocReader;
import tools.ReadExcel;
import tools.ReadingPdf;

public class ActionServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static String SavePath = "";
	String allqnum = "";
	String cnum;
	int score = 0;
	String typescore;
	String type;
	String allqscore = "";

	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// 获得请求资源路径
		String uri = request.getRequestURI();
		// 分析请求资源路径，进行相应的处理
		String path = uri.substring(uri.lastIndexOf("/"), uri.lastIndexOf("."));
		System.out.println("path：" + path);

		SavePath = getServletContext().getRealPath("/") + "upload\\";

		request.setCharacterEncoding("utf-8");
		Users emp = (Users) request.getSession().getAttribute("user");

		if ("/login".equals(path)) {
			try {
				UsersDAO dao = new UsersDAO();
				String phone = request.getParameter("phone");
				// 验证码
				String num = request.getParameter("cpwd");
				String identity = request.getParameter("identity");
				Users user;
				while ((user = dao.findByPhone(phone)) == null) {
					// 将用户信息插入到数据库
					user = new Users();
					user.setPhone(phone);
					user.setIdentity(identity);
					dao.addByPhone(user);
				}
				if (cnum.equals(num)) {
					String ident = user.getIdentity();
					HttpSession session = request.getSession();
					session.setAttribute("user", user);
					if (ident.equals("1")) {
						response.sendRedirect("admin/information.jsp");
					} else if (ident.equals("2")) {
						response.sendRedirect("company/information.jsp");
					} else if (ident.equals("3")) {
						response.sendRedirect("applicant/paperlist.jsp?onephone=" + phone);
					}

				} else {
					System.out.println("wrong cnum");
				}
				cnum = "";
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} else if ("/info".equals(path)) {
			try {
				UsersDAO dao = new UsersDAO();
				Users user = dao.findByPhone(emp.getPhone());
				// 1.绑定数据到request对象上
				request.setAttribute("user", user);
				// 2.获得转发器
				RequestDispatcher rd = request.getRequestDispatcher("information.jsp");
				// 3.转发
				rd.forward(request, response);
			} catch (SQLException e) {
				e.printStackTrace();
				// 将异常抛出，交给容器来处理
				throw new ServletException(e);
			}
		} else if ("/modify".equals(path)) {
			UsersDAO dao = new UsersDAO();

			String name = request.getParameter("name");
			String gender = request.getParameter("gender");
			String age = request.getParameter("age");
			String phone = request.getParameter("phone");

			Users user = new Users();
			try {
				user.setName(name);
				if (gender != null) {
					user.setGender(gender);
				}
				user.setAge(Integer.parseInt(age));
				user.setPhone(phone);
				dao.modify(user, emp.getPhone());
				response.sendRedirect("info.do");
			} catch (Exception e) {
				e.printStackTrace();
				throw new ServletException(e);
			}
		} else if ("/examset".equals(path)) {
			try {
				String startdate = request.getParameter("startdate");
				String starttime = request.getParameter("starttime");
				String enddate = request.getParameter("enddate");
				String endtime = request.getParameter("endtime");
				String phones = request.getParameter("phones");
				System.out.println("phones" + phones);
				String[] pn = phones.split(";");
				for (String pho : pn) {
					System.out.println(pho);
					String start = startdate + " " + starttime;

//					CommonRpc.sendMessage(pho, start);
				}
				int paperid = Integer.parseInt(request.getParameter("paperid"));

				PaperDAO dao = new PaperDAO();
				dao.updatePaperSet(startdate, starttime, enddate, endtime, phones, paperid);

				response.sendRedirect("paperlist.jsp?phone=" + emp.getPhone());
			} catch (SQLException e) {
				e.printStackTrace();
				// 将异常抛出，交给容器来处理
				throw new ServletException(e);
			}
		} else if ("/answer".equals(path)) {
			String total = request.getParameter("total");
			String qanswer = "";

			for (int i = 0; i < Integer.parseInt(total); i++) {
				String qq = "qanswer" + i;
				String qa = request.getParameter(qq);
				qanswer += qa + ";";
			}
			System.out.println(qanswer);

			AnswerDAO dao = new AnswerDAO();
			Answer answer = new Answer();
			String paperid = request.getParameter("paperid");
			String phone = request.getParameter("phone");
			String processlist = request.getParameter("processlist");
			try {
				Monitor m = new Monitor();
				m.setPaperid(Integer.parseInt(paperid));
				m.setPhone(phone);
				m.setProcesslist(processlist);
				MonitorDAO mdao = new MonitorDAO();
				mdao.addAnswer(m);
				answer.setaNum(qanswer);
				answer.setPhone(phone);
				dao.addAnswer(Integer.parseInt(paperid), qanswer, phone);

				PaperDAO pdao = new PaperDAO();
				Paper paper = pdao.showPaperByPaperid(Integer.parseInt(paperid));
				// 题号qnum是中间以,相隔的字符串
				String qnum = paper.getqNum();
				// 小题分是中间以;相隔的字符串，最后还有一个;用户答案qanswer也同样
				String agrade = paper.getqGrade();
				System.out.println("agrade" + agrade);
				int grade = 0;

				String qid[] = qnum.split(",");
				String grades[] = agrade.split(";");
				QuestionDAO qdao = new QuestionDAO();
				for (int i = 0; i < qid.length; i++) {
					QuestionRecord question = qdao.showQuestionByQid(Integer.parseInt(qid[i]));
					String qaInPaper = question.getQAnswer();
					String qq = "qanswer" + i;
					String qaInUser = request.getParameter(qq);
					if (qaInUser.equals(qaInPaper)) {
						grade += Integer.parseInt(grades[i]);
					} else {
						grade += 0;
					}
				}
				System.out.println("grade" + grade);

				List<Answer> answers = dao.showGraderListByPhone(phone);
				Answer newestanswer = answers.get(0);
				int answerid = newestanswer.getAnswerid();
				dao.addGrade(grade + "", answerid);

				response.sendRedirect("grade.do");
			} catch (Exception e) {
				e.printStackTrace();
				throw new ServletException(e);
			}

		} else if ("/answertest".equals(path)) {
			String paperid = request.getParameter("paperid");
			String phone = request.getParameter("phone");
			try {

				PaperDAO pdao = new PaperDAO();
				Paper paper = pdao.showPaperByPaperid(Integer.parseInt(paperid));
				// 题号qnum是中间以,相隔的字符串
				String qnum = paper.getqNum();
				String qid[] = qnum.split(",");
				QuestionDAO qdao = new QuestionDAO();
				WrongDAO wdao = new WrongDAO();
				for (int i = 0; i < qid.length; i++) {
					QuestionRecord question = qdao.showQuestionByQid(Integer.parseInt(qid[i]));
					String qaInPaper = question.getQAnswer();
					String qq = "qanswer" + i;
					String qaInUser = request.getParameter(qq);
					if (!qaInUser.equals(qaInPaper)) {
						System.out.println(qid[i] + "  " + phone);
						wdao.addWrongQnum(Integer.parseInt(qid[i]), phone);
					}
				}
				response.sendRedirect("showwrong.do");
			} catch (Exception e) {
				e.printStackTrace();
				throw new ServletException(e);
			}
		} else if ("/grade".equals(path)) {
			try {
				UsersDAO dao = new UsersDAO();
				Users user = dao.findByPhone(emp.getPhone());
				// 1.绑定数据到request对象上
				request.setAttribute("user", user);
				// 2.获得转发器
				RequestDispatcher rd = request.getRequestDispatcher("grades.jsp");
				// 3.转发
				rd.forward(request, response);
			} catch (SQLException e) {
				e.printStackTrace();
				// 将异常抛出，交给容器来处理
				throw new ServletException(e);
			}
		} else if ("/showwrong".equals(path)) {
			try {
				UsersDAO dao = new UsersDAO();
				Users user = dao.findByPhone(emp.getPhone());
				// 1.绑定数据到request对象上
				request.setAttribute("user", user);
				// 2.获得转发器
				RequestDispatcher rd = request.getRequestDispatcher("wrongqnum.jsp");
				// 3.转发
				rd.forward(request, response);
			} catch (SQLException e) {
				e.printStackTrace();
				// 将异常抛出，交给容器来处理
				throw new ServletException(e);
			}
		} else if (("/extract".equals(path))) {
			boolean isMultipart;
			Date now = new Date();
			SimpleDateFormat ft = new SimpleDateFormat("yyyy.MM.dd");
			System.out.println(ft.format(now));
			String filePath = SavePath + "extract\\" + ft.format(now) + "\\";
			File myPath = new File(filePath);
			if (!myPath.exists())
				myPath.mkdirs();
			System.out.println("创建文件夹路径为：" + filePath);
			int maxFileSize = 50 * 1024 * 1024;
			int maxMemSize = 4 * 1024 * 1024;
			File file;
			isMultipart = ServletFileUpload.isMultipartContent(request);
			response.setContentType("text/html");
			response.setCharacterEncoding("UTF-8");
			java.io.PrintWriter out = response.getWriter();

			DiskFileItemFactory factory = new DiskFileItemFactory();

			// maximum size that will be stored in memory
			factory.setSizeThreshold(maxMemSize);

			// Location to save data that is larger than maxMemSize.
			factory.setRepository(new File(filePath));

			// Create a new file upload handler
			ServletFileUpload upload = new ServletFileUpload(factory);

			// maximum file size to be uploaded.
			upload.setSizeMax(maxFileSize);

			try {
				// Parse the request to get file items.
				List fileItems = upload.parseRequest(request);

				// Process the uploaded file items
				Iterator i = fileItems.iterator();

				out.println("<html>");
				out.println("<head>");
				out.println("<title>Servlet upload</title>");
				out.println("</head>");
				out.println("<body>");

				while (i.hasNext()) {
					FileItem fi = (FileItem) i.next();
					if (!fi.isFormField()) {
						// Get the uploaded file parameters
						String fieldName = fi.getFieldName();
						String fileName = fi.getName();
						String contentType = fi.getContentType();
						boolean isInMemory = fi.isInMemory();
						long sizeInBytes = fi.getSize();
						System.out.println(fileName);
						// Write the file
						String path1 = "";
						if (fileName.lastIndexOf("\\") >= 0) {
							path1 = filePath + fileName.substring(fileName.lastIndexOf("\\"));
						} else {
							path1 = filePath + fileName.substring(fileName.lastIndexOf("\\") + 1);
						}
						System.out.println(path1);
						File file1 = new File(path1);
						fi.write(file1);
						out.println("Uploaded Filename: " + fileName + "<br>");
						String res = "";
						if (fileName.endsWith(".jpg") || fileName.endsWith(".png") || fileName.endsWith(".bmp")
								|| fileName.endsWith(".jpeg")) {
							res = BaiduOCR.extract(path1);
						} else if (fileName.endsWith(".pdf")) {
							res = ReadingPdf.getText(path1);
						} else if (fileName.endsWith(".docx")) {
							res = DocReader.readDocxFile(path1);
						} else if (fileName.endsWith(".doc")) {
							res = DocReader.readDocFile(path1);
						}
//						out.println(res);
						request.setAttribute("questiontext", res);
						request.getRequestDispatcher("/company/uploadfile.jsp").forward(request, response);
//						file1.delete();
//						System.out.println("删除成功");
					}
				}
				out.println("</body>");
				out.println("</html>");
			} catch (Exception ex) {
				System.out.println(ex);
			}
		} else if (("/extract2".equals(path))) {
			boolean isMultipart;
			Date now = new Date();
			SimpleDateFormat ft = new SimpleDateFormat("yyyy.MM.dd");
			System.out.println(ft.format(now));
			String filePath = SavePath + "extract\\" + ft.format(now) + "\\";
			File myPath = new File(filePath);
			if (!myPath.exists())
				myPath.mkdirs();
			System.out.println("创建文件夹路径为：" + filePath);
			int maxFileSize = 50 * 1024 * 1024;
			int maxMemSize = 4 * 1024 * 1024;
			File file;
			isMultipart = ServletFileUpload.isMultipartContent(request);
			response.setContentType("text/html");
			response.setCharacterEncoding("UTF-8");
			java.io.PrintWriter out = response.getWriter();

			DiskFileItemFactory factory = new DiskFileItemFactory();

			// maximum size that will be stored in memory
			factory.setSizeThreshold(maxMemSize);

			// Location to save data that is larger than maxMemSize.
			factory.setRepository(new File(filePath));

			// Create a new file upload handler
			ServletFileUpload upload = new ServletFileUpload(factory);

			// maximum file size to be uploaded.
			upload.setSizeMax(maxFileSize);

			try {
				// Parse the request to get file items.
				List fileItems = upload.parseRequest(request);

				// Process the uploaded file items
				Iterator i = fileItems.iterator();

				out.println("<html>");
				out.println("<head>");
				out.println("<title>Servlet upload</title>");
				out.println("</head>");
				out.println("<body>");

				while (i.hasNext()) {
					FileItem fi = (FileItem) i.next();
					if (!fi.isFormField()) {
						// Get the uploaded file parameters
						String fieldName = fi.getFieldName();
						String fileName = fi.getName();
						String contentType = fi.getContentType();
						boolean isInMemory = fi.isInMemory();
						long sizeInBytes = fi.getSize();
						System.out.println(fileName);
						// Write the file
						String path1 = "";
						if (fileName.lastIndexOf("\\") >= 0) {
							path1 = filePath + fileName.substring(fileName.lastIndexOf("\\"));
						} else {
							path1 = filePath + fileName.substring(fileName.lastIndexOf("\\") + 1);
						}
						System.out.println(path1);
						File file1 = new File(path1);
						fi.write(file1);
						out.println("Uploaded Filename: " + fileName + "<br>");
						String res = "";
						if (fileName.endsWith(".jpg") || fileName.endsWith(".png") || fileName.endsWith(".bmp")
								|| fileName.endsWith(".jpeg")) {
							res = BaiduOCR.extract(path1);
						} else if (fileName.endsWith(".pdf")) {
							res = ReadingPdf.getText(path1);
						} else if (fileName.endsWith(".docx")) {
							res = DocReader.readDocxFile(path1);
						} else if (fileName.endsWith(".doc")) {
							res = DocReader.readDocFile(path1);
						}
//						out.println(res);
						request.setAttribute("questiontext", res);
						request.getRequestDispatcher("/admin/uploadfile.jsp").forward(request, response);
//						file1.delete();
//						System.out.println("删除成功");
					}
				}
				out.println("</body>");
				out.println("</html>");
			} catch (Exception ex) {
				System.out.println(ex);
			}
		} else if (("/extractexcel".equals(path))) {
			System.out.println(path);
			String paperid = request.getParameter("paperid");
			Date now = new Date();
			SimpleDateFormat ft = new SimpleDateFormat("yyyy.MM.dd");
			System.out.println(ft.format(now));
			String filePath = SavePath + "people\\" + ft.format(now) + "\\";
			File myPath = new File(filePath);
			if (!myPath.exists())
				myPath.mkdirs();
			System.out.println("创建文件夹路径为：" + filePath);
			int maxFileSize = 50 * 1024 * 1024;
			int maxMemSize = 4 * 1024 * 1024;
			DiskFileItemFactory factory = new DiskFileItemFactory();

			// maximum size that will be stored in memory
			factory.setSizeThreshold(maxMemSize);

			// Location to save data that is larger than maxMemSize.
			factory.setRepository(new File(filePath));
			// Create a new file upload handler
			ServletFileUpload upload = new ServletFileUpload(factory);

			// maximum file size to be uploaded.
			upload.setSizeMax(maxFileSize);
			try {
				// Parse the request to get file items.
				List fileItems = upload.parseRequest(request);
				// Process the uploaded file items
				Iterator i = fileItems.iterator();
				while (i.hasNext()) {
					FileItem fi = (FileItem) i.next();
					if (!fi.isFormField()) {
						// Get the uploaded file parameters
						String fileName = fi.getName();
						System.out.println(fileName);
						// Write the file
						String path1 = "";
						if (fileName.lastIndexOf("\\") >= 0) {
							path1 = filePath + fileName.substring(fileName.lastIndexOf("\\"));
						} else {
							path1 = filePath + fileName.substring(fileName.lastIndexOf("\\") + 1);
						}
						System.out.println(path1);
						File file1 = new File(path1);
						fi.write(file1);
						String res = "";
						if (fileName.endsWith(".xls") || fileName.endsWith(".xlsx")) {
							res = ReadExcel.getPhones(path1);
						}
						System.out.println("res++" + res);
						String submittime = request.getParameter("submittime");
						request.setAttribute("filestate", "fileuploaded");
						request.getRequestDispatcher("/company/examset.jsp?paperid=" + paperid + "&phones=" + res)
								.forward(request, response);
					}
				}
			} catch (Exception ex) {
				System.out.println(ex);
			}
		} else if (("/importquestionwithimg".equals(path))) {
			System.out.println(path);
			String qtype = "";
			String qsubject = "";
			String qlevel = "";
			String qcontent = "";
			String qA = "";
			String qB = "";
			String qC = "";
			String qD = "";
			String qanswer = "";
			String path1 = "";
			Date now = new Date();
			SimpleDateFormat ft = new SimpleDateFormat("yyyy.MM.dd");
			System.out.println(ft.format(now));
			String filePath = SavePath + "questionimg\\" + ft.format(now) + "\\";
			File myPath = new File(filePath);
			if (!myPath.exists())
				myPath.mkdirs();
			System.out.println("创建文件夹路径为：" + filePath);
			int maxFileSize = 50 * 1024 * 1024;
			int maxMemSize = 4 * 1024 * 1024;
			DiskFileItemFactory factory = new DiskFileItemFactory();

			// maximum size that will be stored in memory
			factory.setSizeThreshold(maxMemSize);

			// Location to save data that is larger than maxMemSize.
			factory.setRepository(new File(filePath));
			// Create a new file upload handler
			ServletFileUpload upload = new ServletFileUpload(factory);

			// maximum file size to be uploaded.
			upload.setSizeMax(maxFileSize);
			try {
				// Parse the request to get file items.
				List fileItems = upload.parseRequest(request);
				// Process the uploaded file items
				String fileName = "";
				Iterator i = fileItems.iterator();
				while (i.hasNext()) {
					FileItem fi = (FileItem) i.next();
					if (fi.isFormField()) {
						String otherFieldName = fi.getFieldName();
						String otherFieldValue = fi.getString();
						otherFieldName = new String(otherFieldName.getBytes("ISO8859-1"), "utf-8");
						otherFieldValue = new String(otherFieldValue.getBytes("ISO8859-1"), "utf-8");
						System.out.println(otherFieldName + " " + otherFieldValue);
						if (otherFieldName.equals("type"))
							qtype = otherFieldValue;
						if (otherFieldName.equals("subject"))
							qsubject = otherFieldValue;
						if (otherFieldName.equals("level"))
							qlevel = otherFieldValue;
						if (otherFieldName.equals("text"))
							qcontent = otherFieldValue;
						if (otherFieldName.equals("type")) {

							if (otherFieldName.equals("QA"))
								qA = otherFieldValue;
							if (otherFieldName.equals("QB"))
								qB = otherFieldValue;
							if (otherFieldName.equals("QC"))
								qC = otherFieldValue;
							if (otherFieldName.equals("QD"))
								qD = otherFieldValue;
						}
						if (otherFieldName.equals("Qanswer"))
							qanswer = otherFieldValue;
					} else {
						// Get the uploaded file parameters
						fileName = fi.getName();
						System.out.println("myfile++" + fileName);
						// Write the file
						if ("".equals(fileName)) {

							if (fileName.lastIndexOf("\\") >= 0) {
								path1 = filePath + fileName.substring(fileName.lastIndexOf("\\"));
							} else {
								path1 = filePath + fileName.substring(fileName.lastIndexOf("\\") + 1);
							}
							System.out.println(path1);
							if (fileName.endsWith(".jpg") || fileName.endsWith(".png") || fileName.endsWith(".bmp")
									|| fileName.endsWith(".jpeg")) {
								File file1 = new File(path1);
								fi.write(file1);

							}
							System.out.println(path1);
						}
					}
				}
				QuestionRecord ques = new QuestionRecord();

				ques.setQType(qtype);
				ques.setQSubject(qsubject);
				ques.setQLevel(Float.parseFloat(qlevel));
				ques.setQText(qcontent);
				ques.setA(qA);
				ques.setB(qB);
				ques.setC(qC);
				ques.setD(qD);
				ques.setQAnswer(qanswer);
				QuestionDAO qdao = new QuestionDAO();
				if (!"".equals(fileName)) {
					File file1 = new File(path1);
					FileInputStream fis = new FileInputStream(file1);
					qdao.AddQuestionWithPic(ques, fis);
				} else {
					qdao.AddQuestion(ques);
				}
				request.getRequestDispatcher("/company/company.jsp").forward(request, response);
			} catch (Exception ex) {
				System.out.println(ex);
			}
		} else if ("/importquestion".equals(path)) {
			request.setCharacterEncoding("UTF-8");
			response.setContentType("text/html");
			response.setCharacterEncoding("UTF-8");
			QuestionDAO service = new QuestionDAO();

			String QType = request.getParameter("type");

			String subject = request.getParameter("subject");
			float QLevel = Float.parseFloat(request.getParameter("level"));
			String Qtxt[] = request.getParameterValues("text");
			System.out.println(Qtxt.length + "lenget");
			String QAtxt[] = request.getParameterValues("QA");
			String QBtxt[] = request.getParameterValues("QB");
			String QCtxt[] = request.getParameterValues("QC");
			String QDtxt[] = request.getParameterValues("QD");
			String Qans[] = request.getParameterValues("Qanswer");
			for (int i = 0; i < Qtxt.length; i++)
				System.out.println(Qans[i] + "   qtxt");
			for (int i = 0; i < Qtxt.length; i++) {
				QuestionRecord q = new QuestionRecord();
				System.out.println(Qtxt[i]);
				q.setQType(QType);
				q.setQSubject(subject);

				Qtxt[i] = ReplaceString(Qtxt[i]);
				q.setQText(Qtxt[i]);
				System.out.println(Qans[i] + "answer");
				Qans[i] = ReplaceString(Qans[i]);
				q.setQAnswer(Qans[i]);

				q.setQLevel(QLevel);
				if (QType.equals("选择题")) {
					QAtxt[i] = ReplaceString(QAtxt[i]);
					q.setA(QAtxt[i]);
					QBtxt[i] = ReplaceString(QBtxt[i]);
					q.setB(QBtxt[i]);
					QCtxt[i] = ReplaceString(QCtxt[i]);
					q.setC(QCtxt[i]);
					QDtxt[i] = ReplaceString(QDtxt[i]);
					q.setD(QDtxt[i]);
					Qans[i] = ReplaceString(Qans[i]);
					q.setQAnswer(Qans[i]);
				}
				if (service.AddQuestion(q))
					System.out.println(q);

			}
			java.io.PrintWriter out = response.getWriter();
			request.getRequestDispatcher("/company/company.jsp").forward(request, response);
//			out.println("导入成功");
		} else if ("/ShowImage".equals(path)) {
			String questionid = request.getParameter("questionid");
			System.out.println(questionid + "hello");
			QuestionDAO qdao = new QuestionDAO();
			Blob blob = qdao.findImageById(questionid);
			if (blob != null) {
				try {
					ServletOutputStream op = response.getOutputStream();
					byte[] ab = blob.getBytes(1, (int) blob.length());
					response.setContentType("image/gif");
					response.reset();
					op.write(ab);
					op.flush();
					op.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		} else if ("/importquestion2".equals(path)) {
			request.setCharacterEncoding("UTF-8");
			response.setContentType("text/html");
			response.setCharacterEncoding("UTF-8");
			QuestionDAO service = new QuestionDAO();

			String QType = request.getParameter("type");

			String subject = request.getParameter("subject");
			float QLevel = Float.parseFloat(request.getParameter("level"));
			String Qtxt[] = request.getParameterValues("text");
			System.out.println(Qtxt.length + "lenget");
			String QAtxt[] = request.getParameterValues("QA");
			String QBtxt[] = request.getParameterValues("QB");
			String QCtxt[] = request.getParameterValues("QC");
			String QDtxt[] = request.getParameterValues("QD");
			String Qans[] = request.getParameterValues("Qanswer");
			for (int i = 0; i < Qtxt.length; i++)
				System.out.println(Qans[i] + "   qtxt");
			for (int i = 0; i < Qtxt.length; i++) {
				QuestionRecord q = new QuestionRecord();
				System.out.println(Qtxt[i]);
				q.setQType(QType);
				q.setQSubject(subject);

				Qtxt[i] = ReplaceString(Qtxt[i]);
				q.setQText(Qtxt[i]);
				System.out.println(Qans[i] + "answer");
				Qans[i] = ReplaceString(Qans[i]);
				q.setQAnswer(Qans[i]);

				q.setQLevel(QLevel);
				if (QType.equals("选择题")) {
					QAtxt[i] = ReplaceString(QAtxt[i]);
					q.setA(QAtxt[i]);
					QBtxt[i] = ReplaceString(QBtxt[i]);
					q.setB(QBtxt[i]);
					QCtxt[i] = ReplaceString(QCtxt[i]);
					q.setC(QCtxt[i]);
					QDtxt[i] = ReplaceString(QDtxt[i]);
					q.setD(QDtxt[i]);
					Qans[i] = ReplaceString(Qans[i]);
					q.setQAnswer(Qans[i]);
				}
				if (service.AddQuestion(q))
					System.out.println(q);

			}
			java.io.PrintWriter out = response.getWriter();
			request.getRequestDispatcher("/admin/admin.jsp").forward(request, response);
//			out.println("导入成功");
		} else if ("/searchquestion".equals(path)) {
			System.out.println("hello");
			String type = request.getParameter("type");
			String subject = request.getParameter("subject");
			float smalllevel = Float.parseFloat(request.getParameter("smallrate"));
			float largelevel = Float.parseFloat(request.getParameter("largerate"));
			System.out.println(type + subject + smalllevel + largelevel);
			int qnum = Integer.parseInt(request.getParameter("qnum"));
			QuestionDAO service = new QuestionDAO();
			List<QuestionRecord> list = service.getquestions(type, subject, smalllevel, largelevel, allqnum);
			System.out.println("find " + list.size());
			if (list.size() < qnum)
				qnum = list.size();
			int[] randomlist = randomCommon(0, list.size() + 1, qnum);
			System.out.println(randomlist.toString());
			List<QuestionRecord> newlist = new ArrayList<QuestionRecord>();
			for (int i : randomlist) {
				System.out.println(i);
				newlist.add(list.get(i - 1));
			}

			request.setAttribute("questionlist", newlist);
			request.setAttribute("subject", subject);
			request.setAttribute("allscore", allqscore);
			request.getRequestDispatcher("/company/createpaper.jsp").forward(request, response);
		} else if ("/searchquestion2".equals(path)) {
			System.out.println("hello");
			String type = request.getParameter("type");
			String subject = request.getParameter("subject");
			float smalllevel = Float.parseFloat(request.getParameter("smallrate"));
			float largelevel = Float.parseFloat(request.getParameter("largerate"));
			System.out.println(type + subject + smalllevel + largelevel);
			int qnum = Integer.parseInt(request.getParameter("qnum"));
			QuestionDAO service = new QuestionDAO();
			List<QuestionRecord> list = service.getquestions(type, subject, smalllevel, largelevel, allqnum);
			System.out.println("find " + list.size());
			if (list.size() < qnum)
				qnum = list.size();
			int[] randomlist = randomCommon(0, list.size() + 1, qnum);
			System.out.println(randomlist.toString());
			List<QuestionRecord> newlist = new ArrayList<QuestionRecord>();
			for (int i : randomlist) {
				System.out.println(i);
				newlist.add(list.get(i - 1));
			}
			request.setAttribute("allscore", allqscore);
			request.setAttribute("questionlist", newlist);
			request.setAttribute("subject", subject);
			request.getRequestDispatcher("/admin/createpaper.jsp").forward(request, response);

		} else if ("/addquestion".equals(path)) {
			String QNum = request.getParameter("QNum");
			System.out.println("Qnum " + QNum);
			String score = request.getParameter("score");
			String subject = request.getParameter("subject");
			subject = new String(subject.getBytes("ISO8859-1"), "utf-8");
			allqnum += QNum + ",";
			String[] count = QNum.split(",");
			for (int i = 0; i < count.length; i++)
				allqscore += score + ",";
			System.out.println(allqnum);
			System.out.println(allqscore);
			request.setAttribute("allscore", allqscore);
			request.setAttribute("allqscore", allqscore);
			request.getRequestDispatcher("/company/createpaper.jsp").forward(request, response);

		} else if ("/addquestion2".equals(path)) {
			String QNum = request.getParameter("QNum");
			System.out.println("Qnum " + QNum);
			String score = request.getParameter("score");
			String subject = request.getParameter("subject");
			subject = new String(subject.getBytes("ISO8859-1"), "utf-8");
			allqnum += QNum + ",";
			String[] count = QNum.split(",");
			for (int i = 0; i < count.length; i++)
				allqscore += score + ",";
			System.out.println(allqnum);
			System.out.println(allqscore);
			request.setAttribute("allscore", allqscore);
			request.setAttribute("allqscore", allqscore);
			request.getRequestDispatcher("/admin/createpaper.jsp").forward(request, response);

		} else if ("/showpaper".equals(path)) {
			QuestionDAO service = new QuestionDAO();
			List<QuestionRecord> list1 = new ArrayList<QuestionRecord>();
			request.setAttribute("allqscore", allqscore);
			list1 = service.findQuestion(allqnum.substring(0, allqnum.length() - 1));
			System.out.println(list1.size() + "lsit1");
			request.setAttribute("confirmquestionlist", list1);
			List<typeScoreRecord> typelist = new ArrayList<typeScoreRecord>();
			TypeScoreDAO typeservice = new TypeScoreDAO();
			typelist = typeservice.getTypeScores();
			request.setAttribute("typelist", typelist);

			request.getRequestDispatcher("/company/showpaper.jsp?QNum=" + allqnum).forward(request, response);
		} else if ("/showpaper2".equals(path)) {
			QuestionDAO service = new QuestionDAO();
			List<QuestionRecord> list1 = new ArrayList<QuestionRecord>();
			request.setAttribute("allqscore", allqscore);
			list1 = service.findQuestion(allqnum.substring(0, allqnum.length() - 1));
			System.out.println(list1.size() + "lsit1");
			request.setAttribute("confirmquestionlist", list1);
			List<typeScoreRecord> typelist = new ArrayList<typeScoreRecord>();
			TypeScoreDAO typeservice = new TypeScoreDAO();
			typelist = typeservice.getTypeScores();
			request.setAttribute("typelist", typelist);
			request.getRequestDispatcher("/admin/showpaper.jsp?QNum=" + allqnum).forward(request, response);
		} else if ("/confirmpaper".equals(path)) {
			Users emp2 = (Users) request.getSession().getAttribute("user");
			String phone = emp2.getPhone();
			PaperDAO pd = new PaperDAO();

			request.setAttribute("score", allqscore);

			String QNum = request.getParameter("QNum");
			// 数QNum里有几个逗号
			int count = QNum.length() - QNum.replace(",", "").length();

			try {
				pd.addPaper(QNum, allqscore, phone);
				System.out.println("试卷成功入库");
				request.getRequestDispatcher("/company/paperlist.jsp?phone=" + phone).forward(request, response);
			} catch (SQLException e) {
				e.printStackTrace();
			}
			allqnum = "";
			allqscore = "";
		} else if ("/confirmpaper2".equals(path)) {
			Users emp2 = (Users) request.getSession().getAttribute("user");
			String phone = emp2.getPhone();
			PaperDAO pd = new PaperDAO();

			request.setAttribute("score", allqscore);

			String QNum = request.getParameter("QNum");
			// 数QNum里有几个逗号
			int count = QNum.length() - QNum.replace(",", "").length();

			try {
				pd.addPaper(QNum, allqscore, phone);
				System.out.println("试卷成功入库");
				request.getRequestDispatcher("/admin/paperlist.jsp?phone=" + phone).forward(request, response);
			} catch (SQLException e) {
				e.printStackTrace();
			}
			allqnum = "";
			allqscore = "";
		} else if ("/getconfirmnum".equals(path)) {
			String phone = request.getParameter("phone");
			int num = (int) ((Math.random() * 9 + 1) * 100000);
			cnum = num + "";
			System.out.println("验证码：" + cnum);
//			CommonRpc.sendConfirmNum(phone, cnum + "");
		} else if ("/sendmessage".equals(path)) {
			String phones = request.getParameter("phone");
			String p[] = phones.split(",");
			for (String pi : p) {
				if (!"".equals(pi)) {

					CommonRpc.sendConfirmNum(pi, "passthisexam");
					System.out.println(pi + "已发送");
				}
			}
			response.sendRedirect("../applicant/information.jsp");
		}
		else if ("/recharge".equals(path)) {
			String smoney = request.getParameter("charge");
			float money=Float.parseFloat(smoney);
			String phone = request.getParameter("phone");
			UsersDAO udao=new UsersDAO();
			if(udao.updateMoney(phone, money)) {
				response.sendRedirect("recharge.jsp");
			}
			
		}


	}

	public static String ReplaceString(String s) {
		s = s.replace("<", "&lt;");
		s = s.replace(">", "&gt;");
		s = s.replace("\r", "&nbsp;");
		s = s.replaceAll("[\\t\\n]", "<br>");
		return s;
	}

	public static int[] randomCommon(int min, int max, int n) {
		if (n > (max - min + 1) || max < min) {
			return null;
		}
		int[] result = new int[n];
		int count = 0;
		while (count < n) {
			int num = (int) (Math.random() * (max - min)) + min;
			boolean flag = true;
			for (int j = 0; j < n; j++) {
				if (num == result[j]) {
					flag = false;
					break;
				}
			}
			if (flag) {
				result[count] = num;
				count++;
			}
		}
		return result;
	}

}